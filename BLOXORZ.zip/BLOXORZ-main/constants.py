
# Mode of the game 
MANUAL_MODE = 0
DFS_MODE = 1
GA_MODE = 2

# size on screen
CELL_SIZE = 64